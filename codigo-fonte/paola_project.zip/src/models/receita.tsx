export default class Receita {
    titulo: string;
    ingredientes: string[];
    modoDePreparo: string;
    receitaImagem: string;

    public constructor(titulo: string, ingredientes: string[],
        modoDePreparo: string, receitaImagem: string
    ) {
        this.titulo = titulo;
        this.ingredientes = ingredientes;
        this.modoDePreparo = modoDePreparo;
        this.receitaImagem = receitaImagem;
      }
}