import React from "react";
import Receita from '@/models/receita'

type Props = {
    receita: Receita
}


export function ReceitaComponent({ receita } : Props) {
    return(
        <>
            <h1>{receita?.titulo}</h1>
            <div style={{ height: "10px" }}></div>
            <div style={{width: "50%", float : "left" }}>
                <h3>Ingredientes</h3>
                <div style={{ height: "20px" }}></div>
                <u>
                    {receita?.ingredientes.map((ingrediente) => <li>{ingrediente}</li>) }
                </u>
            </div>
            <div style={{'width': '50%', float: 'right'}}>
                <img src={receita?.receitaImagem}/>
            </div>
            <h2 style={{marginTop: '220px', paddingTop: '20px'}}>Modo de preparo</h2>
            <p style={{ marginTop:'6px'}} >
            {receita?.modoDePreparo.split('\n').map( (it, i) => <div key={'x'+i} style={{marginTop: '6px'}}>{it}</div> )}
            </p>
        </>
    )
}