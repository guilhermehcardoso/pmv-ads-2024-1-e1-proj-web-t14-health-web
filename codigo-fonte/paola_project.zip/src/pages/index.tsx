import Head from "next/head";
import Image from "next/image";
import { Inter } from "next/font/google";
import  "@/styles/footer.module.css";
import "@/styles/header.module.css";
import "@/styles/home.module.css";
import "@/styles/testimonials.module.css";
import { useEffect, useState } from "react";
import Receita from "@/models/receita";
import { ReceitaComponent } from "@/components/receita.component";

const inter = Inter({ subsets: ["latin"] });

export default function Home() {

  const [receitas, setReceitas] = useState<Receita[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    fetch('json/receitas.json', {
      method: 'GET',
    })
      .then((res) => res.json())
      .then((res) => setReceitas(res))
      .catch((err) => err);

  }, []);

  function changeIndex(value : number) {
    if(currentIndex + value >= 0 && currentIndex + value <= receitas.length) {
      setCurrentIndex(currentIndex + value);
    }
  }

  return (
    <>
      <Head>
        <title>Health_Web | Paola</title>
        <meta name="Paola" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossOrigin="anonymous" referrerPolicy="no-referrer" />
        <link rel="stylesheet" href="src/styles/styles.css" />

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossOrigin="anonymous" referrerPolicy="no-referrer"></script>
        <script src="https://unpkg.com/scrollreveal"></script>
      </Head>
      <header>
        <nav id="navbar">
            <i className="fa-solid fa-weight-scale"id="nav_logo"> Health_Web</i>

            <ul id="nav_list">
                <li className="nav-item active">
                    <a href="#home">Início</a>
                </li>
                <li className="nav-item">
                    <a href="#menu">Receita do dia</a>
                </li>
                
            </ul>

            <button className="btn-default">
         E-book
            </button>

            <button id="mobile_btn">
                <i className="fa-solid fa-bars"></i>
            </button>
        </nav>

        <div id="mobile_menu">
            <ul id="mobile_nav_list">
                <li className="nav-item">
                    <a href="#home">Início</a>
                </li>
                <li className="nav-item">
                    <a href="#menu">Cardápio</a>
                </li>
                
            </ul>

            <button className="btn-default">
                Agendamento 
            </button>
        </div>
    </header>

    <main id="content">
        <section id="home">
            <div className="shape"></div>
            <div id="cta">
                <h1 className="title">
                    Alimentação <br/>
                    <span>Saudável</span>
                </h1>

                <p className="description">
                    A alimentação saudável propicia ao organismo bons nutrientes, para que ele se mantenha funcionando de forma equilibrada. É a partir do que ingerimos que criamos energia para a realização de nossas atividades diárias.
                </p>

                <div id="cta_buttons">
                    <a href="#" className="btn-default">
                        Falar com a Nutri
                    </a>

                    <a href="tel:+55555555555" id="phone_button">
                        <button className="btn-default">
                            <i className="fa-solid fa-phone"></i>
                        </button>
                     (31) 33194444
                        
                    </a>
                </div>

                <div className="social-media-buttons">
                    <a href="">
                        <i className="fa-brands fa-whatsapp"></i>
                    </a>

                    <a href="">
                        <i className="fa-brands fa-instagram"></i>
                    </a>

                    <a href="">
                        <i className="fa-brands fa-facebook"></i>
                    </a>
                </div>
            </div>
                
            <div id="banner">
                <img src="images/Imagem do WhatsApp de 2024-05-10 à(s) 07.26.04_c7c75291.jpg" alt="" />
            </div>
        </section>      
  <section id="testimonials">
    <img src="images/chef.png" id="testimonial_chef" alt="" />
                    <div id="banner">
                        <ReceitaComponent receita={receitas[currentIndex] } />
                        <div style={{ height: "20px" }}></div>
                        <div style={{margin: "auto", width: '20%'}}>
                            <button className="previous disable" id="previous" onClick={() => changeIndex(-1)}>Previous</button>
                            <button className="next" id="next" onClick={() => changeIndex(+1)}>Next</button>
                        </div>
                    </div>
                </section>
    </main>

    
        <div id="footer_items">
            <span id="copyright">
                &copy 2024 Paola Beltrão
            </span>

            <div className="social-media-buttons">
                <a href="">
                    <i className="fa-brands fa-whatsapp"></i>
                </a>

                <a href="">
                    <i className="fa-brands fa-instagram"></i>
                </a>

                <a href="">
                    <i className="fa-brands fa-facebook"></i>
                </a>
            </div>
        </div>
    <script src="javascript/script.js"></script>
    </>
  );
}
